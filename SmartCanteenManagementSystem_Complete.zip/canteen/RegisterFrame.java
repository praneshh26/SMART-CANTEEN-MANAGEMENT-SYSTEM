package canteen;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class RegisterFrame extends JFrame {
    private final JFrame parent;
    private final JTextField fullName = new JTextField(18);
    private final JTextField username = new JTextField(18);
    private final JTextField email = new JTextField(18);
    private final JComboBox<String> roleCombo = new JComboBox<>(new String[]{"CUSTOMER", "CANTEEN_STAFF"});
    private final JPasswordField password = new JPasswordField(18);
    private final JPasswordField confirm = new JPasswordField(18);

    public RegisterFrame(JFrame parent) {
        this.parent = parent;
        setTitle("Smart Canteen - User Registration");
        setSize(520, 460);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(ThemeUI.BG_CREAM);

        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 14));
        header.setBackground(ThemeUI.PASTEL_LAVENDER);
        JLabel title = new JLabel("CREATE CANTEEN ACCOUNT", ThemeUI.createCanteenIcon("LOGO", 36), JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(ThemeUI.HEADER_SAGE);
        header.add(title);
        add(header, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(6, 2, 10, 12));
        form.setBackground(ThemeUI.BG_CREAM);
        form.setBorder(BorderFactory.createEmptyBorder(20, 35, 15, 35));

        form.add(new JLabel("Full Name:"));
        form.add(fullName);
        form.add(new JLabel("Username:"));
        form.add(username);
        form.add(new JLabel("Email:"));
        form.add(email);
        form.add(new JLabel("Role:"));
        form.add(roleCombo);
        form.add(new JLabel("Password:"));
        form.add(password);
        form.add(new JLabel("Confirm Password:"));
        form.add(confirm);

        JButton create = new JButton("Create Account");
        JButton back = new JButton("Back to Login");
        ThemeUI.styleButton(create, ThemeUI.BTN_PRIMARY, Color.WHITE);
        ThemeUI.styleButton(back, ThemeUI.PASTEL_PEACH, ThemeUI.TEXT_DARK);
        getRootPane().setDefaultButton(create);

        create.addActionListener(e -> registerUser());
        back.addActionListener(e -> goBack());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttons.setBackground(ThemeUI.BG_CREAM);
        buttons.add(create);
        buttons.add(back);

        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
    }

    private void registerUser() {
        String name = fullName.getText().trim();
        String user = username.getText().trim();
        String mail = email.getText().trim();
        String role = (String) roleCombo.getSelectedItem();
        String pass = new String(password.getPassword());
        String confirmPass = new String(confirm.getPassword());

        if (name.isEmpty() || user.isEmpty() || mail.isEmpty() || pass.isEmpty() || confirmPass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill in all fields.");
            return;
        }
        if (!pass.equals(confirmPass)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.");
            return;
        }
        if (pass.length() < 8) {
            JOptionPane.showMessageDialog(this, "Password must contain at least 8 characters.");
            return;
        }
        if (!mail.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            JOptionPane.showMessageDialog(this, "Enter a valid email address.");
            return;
        }

        String sql = "INSERT INTO app_users (full_name, username, email, password_hash, role) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, user);
            ps.setString(3, mail);
            ps.setString(4, PasswordUtil.hash(pass));
            ps.setString(5, role);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Registration successful! Please log in.");
            goBack();

        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1 || ex.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(this, "Username or email already exists.");
            } else {
                JOptionPane.showMessageDialog(this, "Registration failed: " + ex.getMessage());
            }
        }
    }

    private void goBack() {
        dispose();
        parent.setVisible(true);
    }
}
