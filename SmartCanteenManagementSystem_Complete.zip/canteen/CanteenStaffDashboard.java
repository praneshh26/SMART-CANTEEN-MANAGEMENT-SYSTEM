package canteen;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class CanteenStaffDashboard extends JFrame {
    private final int adminId;
    private final String adminName;

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(cardLayout);

    private final JLabel lblActiveOrders = new JLabel("0");
    private final JLabel lblDailyRevenue = new JLabel("₹0.00");
    private final JLabel lblTotalUsers = new JLabel("0");

    private final DefaultTableModel orderModel = new DefaultTableModel(
            new String[]{"Order ID", "Token No", "Customer", "Username", "Total (₹)", "Status", "Order Date"}, 0
    ) {
        @Override
        public boolean isCellEditable(int r, int c) { return false; }
    };

    private final DefaultTableModel menuModel = new DefaultTableModel(
            new String[]{"Item ID", "Item Name", "Category", "Price (₹)", "Stock Qty", "Available"}, 0
    ) {
        @Override
        public boolean isCellEditable(int r, int c) { return false; }
    };

    private final DefaultTableModel walletModel = new DefaultTableModel(
            new String[]{"User ID", "Customer Name", "Username", "Wallet Balance (₹)"}, 0
    ) {
        @Override
        public boolean isCellEditable(int r, int c) { return false; }
    };

    private final JTable orderTable = new JTable(orderModel);
    private final JTable menuTable = new JTable(menuModel);
    private final JTable walletTable = new JTable(walletModel);

    public CanteenStaffDashboard() {
        this(1, "Administrator");
    }

    public CanteenStaffDashboard(int adminId, String adminName) {
        this.adminId = adminId;
        this.adminName = adminName;

        setTitle("Smart Canteen - Admin Control Center");
        setSize(1100, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(ThemeUI.BG_CREAM);

        // Header Bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(ThemeUI.HEADER_SAGE);
        topBar.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        JLabel titleLbl = new JLabel("  CANTEEN ADMIN PORTAL  |  Logged in as: " + adminName,
                ThemeUI.createCanteenIcon("LOGO", 32), JLabel.LEFT);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        titleLbl.setForeground(Color.WHITE);

        JPanel headerButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        headerButtons.setOpaque(false);

        JButton homeBtn = new JButton("Home Page");
        JButton refreshBtn = new JButton("Sync Data");
        JButton logoutBtn = new JButton("Logout");
        ThemeUI.styleButton(homeBtn, ThemeUI.PASTEL_SKY, ThemeUI.TEXT_DARK);
        ThemeUI.styleButton(refreshBtn, ThemeUI.PASTEL_MINT, ThemeUI.TEXT_DARK);
        ThemeUI.styleButton(logoutBtn, ThemeUI.PASTEL_PEACH, ThemeUI.TEXT_DARK);

        homeBtn.addActionListener(e -> {
            cardLayout.show(contentPanel, "HOME");
            loadAllData();
        });
        refreshBtn.addActionListener(e -> loadAllData());
        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        headerButtons.add(homeBtn);
        headerButtons.add(refreshBtn);
        headerButtons.add(logoutBtn);

        topBar.add(titleLbl, BorderLayout.WEST);
        topBar.add(headerButtons, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        ThemeUI.styleTable(orderTable);
        ThemeUI.styleTable(menuTable);
        ThemeUI.styleTable(walletTable);

        contentPanel.setBackground(ThemeUI.BG_CREAM);
        contentPanel.add(createHomeLandingPanel(), "HOME");
        contentPanel.add(createMenuManagementPanel(), "MENU");
        contentPanel.add(createRechargePanel(), "RECHARGE");
        contentPanel.add(createOrdersPanel(), "ORDERS");

        add(contentPanel, BorderLayout.CENTER);

        loadAllData();
        cardLayout.show(contentPanel, "HOME");
    }

    private JPanel createHomeLandingPanel() {
        JPanel homePanel = new JPanel(new BorderLayout(20, 20));
        homePanel.setBackground(ThemeUI.BG_CREAM);
        homePanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 40, 40));

        JPanel metricsPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        metricsPanel.setOpaque(false);
        metricsPanel.add(createMetricCard("Live Active Orders", lblActiveOrders, ThemeUI.PASTEL_PEACH, new Color(180, 110, 20)));
        metricsPanel.add(createMetricCard("Today's Revenue", lblDailyRevenue, ThemeUI.PASTEL_MINT, new Color(34, 139, 87)));
        metricsPanel.add(createMetricCard("Registered Customers", lblTotalUsers, ThemeUI.PASTEL_SKY, new Color(41, 128, 185)));

        JPanel actionsGrid = new JPanel(new GridLayout(1, 3, 25, 25));
        actionsGrid.setOpaque(false);
        actionsGrid.setBorder(BorderFactory.createEmptyBorder(30, 0, 10, 0));

        actionsGrid.add(createNavActionCard(
                "Update Menu",
                "Add menu items, edit pricing, restock quantities, or toggle item availability.",
                "Open Menu Control",
                ThemeUI.createCanteenIcon("MENU", 48),
                ThemeUI.PASTEL_MINT,
                e -> cardLayout.show(contentPanel, "MENU")
        ));

        actionsGrid.add(createNavActionCard(
                "Customer Recharge",
                "Add money to customer wallets, inspect balances, and review accounts.",
                "Open Recharge Portal",
                ThemeUI.createCanteenIcon("WALLET", 48),
                ThemeUI.PASTEL_PEACH,
                e -> cardLayout.show(contentPanel, "RECHARGE")
        ));

        actionsGrid.add(createNavActionCard(
                "View Orders",
                "Inspect live customer tokens, track orders, and update preparation statuses.",
                "Open Orders Monitor",
                ThemeUI.createCanteenIcon("HISTORY", 48),
                ThemeUI.PASTEL_LAVENDER,
                e -> cardLayout.show(contentPanel, "ORDERS")
        ));

        homePanel.add(metricsPanel, BorderLayout.NORTH);
        homePanel.add(actionsGrid, BorderLayout.CENTER);

        return homePanel;
    }

    private JPanel createMetricCard(String title, JLabel valueLbl, Color bg, Color accent) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setBorder(ThemeUI.roundedCardBorder(ThemeUI.BORDER_SOFT, 16, 20));
        card.setBackground(bg);

        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tLbl.setForeground(ThemeUI.TEXT_DARK);

        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLbl.setForeground(accent);

        card.add(tLbl, BorderLayout.NORTH);
        card.add(valueLbl, BorderLayout.CENTER);
        return card;
    }

    private JPanel createNavActionCard(String title, String desc, String btnText, Icon icon, Color bg, java.awt.event.ActionListener action) {
        JPanel card = new JPanel(new BorderLayout(15, 15));
        card.setBorder(ThemeUI.roundedCardBorder(ThemeUI.BORDER_SOFT, 25, 20));
        card.setBackground(bg);

        JPanel head = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        head.setOpaque(false);
        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        tLbl.setForeground(ThemeUI.TEXT_DARK);
        head.add(new JLabel(icon));
        head.add(tLbl);

        JTextArea descArea = new JTextArea(desc);
        descArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        descArea.setForeground(ThemeUI.TEXT_DARK);
        descArea.setWrapStyleWord(true);
        descArea.setLineWrap(true);
        descArea.setEditable(false);
        descArea.setOpaque(false);
        descArea.setFocusable(false);

        JButton actionBtn = new JButton(btnText);
        ThemeUI.styleButton(actionBtn, ThemeUI.HEADER_SAGE, Color.WHITE);
        actionBtn.setPreferredSize(new Dimension(180, 40));
        actionBtn.addActionListener(action);

        card.add(head, BorderLayout.NORTH);
        card.add(descArea, BorderLayout.CENTER);
        card.add(actionBtn, BorderLayout.SOUTH);
        return card;
    }

    private JPanel createMenuManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(ThemeUI.BG_CREAM);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JPanel topNav = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        topNav.setOpaque(false);
        JButton backBtn = new JButton("← Back to Dashboard");
        ThemeUI.styleButton(backBtn, ThemeUI.PASTEL_LAVENDER, ThemeUI.TEXT_DARK);
        backBtn.addActionListener(e -> cardLayout.show(contentPanel, "HOME"));

        JLabel pageTitle = new JLabel("   Menu & Inventory Management", ThemeUI.createCanteenIcon("MENU", 28), JLabel.LEFT);
        pageTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        pageTitle.setForeground(ThemeUI.HEADER_SAGE);
        topNav.add(backBtn);
        topNav.add(pageTitle);

        panel.add(topNav, BorderLayout.NORTH);
        panel.add(new JScrollPane(menuTable), BorderLayout.CENTER);

        JTextField txtName = new JTextField(12);
        JComboBox<String> cmbCat = new JComboBox<>(new String[]{"Breakfast", "Lunch", "Snacks", "Beverages"});
        JTextField txtPrice = new JTextField(6);
        JTextField txtStock = new JTextField(6);

        JPanel inputGrid = new JPanel(new GridLayout(2, 4, 10, 8));
        inputGrid.setOpaque(false);
        inputGrid.add(new JLabel("Item Name:"));
        inputGrid.add(new JLabel("Category:"));
        inputGrid.add(new JLabel("Price (₹):"));
        inputGrid.add(new JLabel("Stock Quantity:"));

        inputGrid.add(txtName);
        inputGrid.add(cmbCat);
        inputGrid.add(txtPrice);
        inputGrid.add(txtStock);

        JButton btnAdd = new JButton("Add Item");
        JButton btnUpdateStock = new JButton("Update Stock of Selected");
        JButton btnToggle = new JButton("Toggle Availability");
        ThemeUI.styleButton(btnAdd, ThemeUI.BTN_PRIMARY, Color.WHITE);
        ThemeUI.styleButton(btnUpdateStock, ThemeUI.PASTEL_SKY, ThemeUI.TEXT_DARK);
        ThemeUI.styleButton(btnToggle, ThemeUI.PASTEL_PEACH, ThemeUI.TEXT_DARK);

        btnAdd.addActionListener(e -> {
            try {
                String name = txtName.getText().trim();
                double price = Double.parseDouble(txtPrice.getText().trim());
                int stock = Integer.parseInt(txtStock.getText().trim());
                if (name.isEmpty() || price <= 0 || stock < 0) throw new NumberFormatException();

                String sql = "INSERT INTO menu_items (item_name, category, price, stock_quantity, available) VALUES (?, ?, ?, ?, 'Y')";
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, name);
                    ps.setString(2, (String) cmbCat.getSelectedItem());
                    ps.setDouble(3, price);
                    ps.setInt(4, stock);
                    ps.executeUpdate();
                }

                JOptionPane.showMessageDialog(this, "Item added successfully!");
                txtName.setText("");
                txtPrice.setText("");
                txtStock.setText("");
                loadAllData();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter valid positive numeric values for price and stock.");
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        btnUpdateStock.addActionListener(e -> {
            int row = menuTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select a menu item from the table first.");
                return;
            }
            int itemId = (Integer) menuModel.getValueAt(menuTable.convertRowIndexToModel(row), 0);
            String input = JOptionPane.showInputDialog(this, "Enter updated stock quantity:");
            if (input != null && !input.trim().isEmpty()) {
                try {
                    int newStock = Integer.parseInt(input.trim());
                    if (newStock < 0) throw new NumberFormatException();
                    String sql = "UPDATE menu_items SET stock_quantity = ?, available = IF(? > 0, 'Y', 'N') WHERE item_id = ?";
                    try (Connection con = DBConnection.getConnection();
                         PreparedStatement ps = con.prepareStatement(sql)) {
                        ps.setInt(1, newStock);
                        ps.setInt(2, newStock);
                        ps.setInt(3, itemId);
                        ps.executeUpdate();
                    }
                    loadAllData();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Stock must be 0 or a positive integer.");
                }
            }
        });

        btnToggle.addActionListener(e -> {
            int row = menuTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select a menu item from the table first.");
                return;
            }
            int itemId = (Integer) menuModel.getValueAt(menuTable.convertRowIndexToModel(row), 0);
            String current = (String) menuModel.getValueAt(menuTable.convertRowIndexToModel(row), 5);
            String next = "Y".equalsIgnoreCase(current) ? "N" : "Y";

            String sql = "UPDATE menu_items SET available = ? WHERE item_id = ?";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, next);
                ps.setInt(2, itemId);
                ps.executeUpdate();
                loadAllData();
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        JPanel bottomArea = new JPanel(new BorderLayout(10, 10));
        bottomArea.setOpaque(false);
        bottomArea.add(inputGrid, BorderLayout.CENTER);

        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        btnBar.setOpaque(false);
        btnBar.add(btnAdd);
        btnBar.add(btnUpdateStock);
        btnBar.add(btnToggle);
        bottomArea.add(btnBar, BorderLayout.SOUTH);

        panel.add(bottomArea, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createRechargePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(ThemeUI.BG_CREAM);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JPanel topNav = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        topNav.setOpaque(false);
        JButton backBtn = new JButton("← Back to Dashboard");
        ThemeUI.styleButton(backBtn, ThemeUI.PASTEL_LAVENDER, ThemeUI.TEXT_DARK);
        backBtn.addActionListener(e -> cardLayout.show(contentPanel, "HOME"));

        JLabel pageTitle = new JLabel("   Customer Wallet Recharge & Balances", ThemeUI.createCanteenIcon("WALLET", 28), JLabel.LEFT);
        pageTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        pageTitle.setForeground(ThemeUI.HEADER_SAGE);
        topNav.add(backBtn);
        topNav.add(pageTitle);

        panel.add(topNav, BorderLayout.NORTH);
        panel.add(new JScrollPane(walletTable), BorderLayout.CENTER);

        JPanel topUpBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 12));
        topUpBar.setOpaque(false);
        JTextField txtUserId = new JTextField(8);
        JTextField txtAmount = new JTextField(10);
        JButton btnTopUp = new JButton("Credit Amount to Wallet");
        ThemeUI.styleButton(btnTopUp, ThemeUI.BTN_PRIMARY, Color.WHITE);

        walletTable.getSelectionModel().addListSelectionListener(e -> {
            int row = walletTable.getSelectedRow();
            if (row >= 0) {
                txtUserId.setText(String.valueOf(walletModel.getValueAt(walletTable.convertRowIndexToModel(row), 0)));
            }
        });

        btnTopUp.addActionListener(e -> {
            try {
                int userId = Integer.parseInt(txtUserId.getText().trim());
                double amount = Double.parseDouble(txtAmount.getText().trim());
                if (amount <= 0) throw new NumberFormatException();

                try (Connection con = DBConnection.getConnection()) {
                    con.setAutoCommit(false);

                    String sqlWallet = "INSERT INTO user_wallets (user_id, balance) VALUES (?, ?) "
                            + "ON DUPLICATE KEY UPDATE balance = balance + ?";
                    try (PreparedStatement ps = con.prepareStatement(sqlWallet)) {
                        ps.setInt(1, userId);
                        ps.setDouble(2, amount);
                        ps.setDouble(3, amount);
                        ps.executeUpdate();
                    }

                    String sqlTxn = "INSERT INTO wallet_transactions (user_id, type, amount) VALUES (?, 'TOPUP', ?)";
                    try (PreparedStatement ps = con.prepareStatement(sqlTxn)) {
                        ps.setInt(1, userId);
                        ps.setDouble(2, amount);
                        ps.executeUpdate();
                    }

                    con.commit();
                    JOptionPane.showMessageDialog(this, "Successfully credited ₹" + amount + " to Customer ID: " + userId);
                    txtUserId.setText("");
                    txtAmount.setText("");
                    loadAllData();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter a valid numeric Customer ID and a positive amount.");
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        topUpBar.add(new JLabel("Customer ID:"));
        topUpBar.add(txtUserId);
        topUpBar.add(new JLabel("Amount (₹):"));
        topUpBar.add(txtAmount);
        topUpBar.add(btnTopUp);

        panel.add(topUpBar, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createOrdersPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(ThemeUI.BG_CREAM);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JPanel topNav = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        topNav.setOpaque(false);
        JButton backBtn = new JButton("← Back to Dashboard");
        ThemeUI.styleButton(backBtn, ThemeUI.PASTEL_LAVENDER, ThemeUI.TEXT_DARK);
        backBtn.addActionListener(e -> cardLayout.show(contentPanel, "HOME"));

        JLabel pageTitle = new JLabel("   Live Token & Order Management", ThemeUI.createCanteenIcon("HISTORY", 28), JLabel.LEFT);
        pageTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        pageTitle.setForeground(ThemeUI.HEADER_SAGE);
        topNav.add(backBtn);
        topNav.add(pageTitle);

        panel.add(topNav, BorderLayout.NORTH);
        panel.add(new JScrollPane(orderTable), BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        actions.setOpaque(false);
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"PREPARING", "READY", "COMPLETED", "CANCELLED"});
        JButton btnUpdateStatus = new JButton("Update Status for Selected Order");
        ThemeUI.styleButton(btnUpdateStatus, ThemeUI.BTN_PRIMARY, Color.WHITE);

        btnUpdateStatus.addActionListener(e -> {
            int row = orderTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select an order row to update.");
                return;
            }
            int orderId = (Integer) orderModel.getValueAt(orderTable.convertRowIndexToModel(row), 0);
            int tokenNo = (Integer) orderModel.getValueAt(orderTable.convertRowIndexToModel(row), 1);
            String newStatus = (String) statusBox.getSelectedItem();

            String sql = "UPDATE orders SET status = ? WHERE order_id = ?";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, newStatus);
                ps.setInt(2, orderId);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Token #" + tokenNo + " marked as " + newStatus);
                loadAllData();
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        actions.add(new JLabel("Set Status:"));
        actions.add(statusBox);
        actions.add(btnUpdateStatus);

        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }

    private void loadAllData() {
        orderModel.setRowCount(0);
        menuModel.setRowCount(0);
        walletModel.setRowCount(0);

        try (Connection con = DBConnection.getConnection()) {
            String orderSql = "SELECT o.order_id, o.token_no, u.full_name, u.username, o.total_amount, o.status, o.order_date "
                    + "FROM orders o JOIN app_users u ON o.user_id = u.id ORDER BY o.order_id DESC";
            try (PreparedStatement ps = con.prepareStatement(orderSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    orderModel.addRow(new Object[]{
                            rs.getInt("order_id"),
                            rs.getInt("token_no"),
                            rs.getString("full_name"),
                            rs.getString("username"),
                            rs.getDouble("total_amount"),
                            rs.getString("status"),
                            rs.getString("order_date")
                    });
                }
            }

            String menuSql = "SELECT item_id, item_name, category, price, stock_quantity, available FROM menu_items ORDER BY item_id ASC";
            try (PreparedStatement ps = con.prepareStatement(menuSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    menuModel.addRow(new Object[]{
                            rs.getInt("item_id"),
                            rs.getString("item_name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getInt("stock_quantity"),
                            rs.getString("available")
                    });
                }
            }

            String walletSql = "SELECT u.id, u.full_name, u.username, COALESCE(w.balance, 0.00) AS balance "
                    + "FROM app_users u LEFT JOIN user_wallets w ON u.id = w.user_id "
                    + "WHERE UPPER(u.role) = 'CUSTOMER' ORDER BY u.id ASC";
            try (PreparedStatement ps = con.prepareStatement(walletSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    walletModel.addRow(new Object[]{
                            rs.getInt("id"),
                            rs.getString("full_name"),
                            rs.getString("username"),
                            rs.getDouble("balance")
                    });
                }
            }

            String metricSql = "SELECT "
                    + "COUNT(CASE WHEN status IN ('PENDING', 'PREPARING', 'READY') THEN 1 END) AS active_count, "
                    + "COALESCE(SUM(CASE WHEN DATE(order_date) = CURRENT_DATE AND status != 'CANCELLED' THEN total_amount ELSE 0 END), 0) AS daily_rev "
                    + "FROM orders";
            try (PreparedStatement ps = con.prepareStatement(metricSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    lblActiveOrders.setText(String.valueOf(rs.getInt("active_count")));
                    lblDailyRevenue.setText("₹" + String.format("%.2f", rs.getDouble("daily_rev")));
                }
            }

            String countUserSql = "SELECT COUNT(*) FROM app_users WHERE UPPER(role) = 'CUSTOMER'";
            try (PreparedStatement ps = con.prepareStatement(countUserSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    lblTotalUsers.setText(String.valueOf(rs.getInt(1)));
                }
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void showError(SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
