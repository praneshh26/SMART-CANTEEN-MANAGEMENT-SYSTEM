package canteen;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class CanteenApp {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ignored) {
            // Continue with the default Swing appearance.
        }
        SwingUtilities.invokeLater(() ->
                new LoginFrame().setVisible(true)
        );
    }
}
