package canteen;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginFrame extends JFrame {
    private final JTextField username = new JTextField(20);
    private final JPasswordField password = new JPasswordField(20);

    public LoginFrame() {
        setTitle("Smart Canteen Management System - Login");
        setSize(640, 470);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(ThemeUI.BG_CREAM);

        // Top Pastel Banner with Canteen Logo & Large Title
        JPanel banner = new JPanel();
        banner.setLayout(new BoxLayout(banner, BoxLayout.Y_AXIS));
        banner.setBackground(ThemeUI.PASTEL_MINT);
        banner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, ThemeUI.BORDER_SOFT),
                BorderFactory.createEmptyBorder(24, 20, 22, 20)
        ));

        JLabel logoIcon = new JLabel(ThemeUI.createCanteenIcon("LOGO", 64));
        logoIcon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("CANTEEN LOGIN");
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title.setForeground(ThemeUI.HEADER_SAGE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Smart Canteen Portal  •  Fast Ordering & Digital Wallet");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(ThemeUI.TEXT_DARK);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        banner.add(logoIcon);
        banner.add(Box.createVerticalStrut(8));
        banner.add(title);
        banner.add(Box.createVerticalStrut(4));
        banner.add(subtitle);
        add(banner, BorderLayout.NORTH);

        // Center Card Container
        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(ThemeUI.BG_CREAM);

        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(ThemeUI.CARD_WHITE);
        formCard.setBorder(ThemeUI.roundedCardBorder(ThemeUI.BORDER_SOFT, 26, 36));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel userLbl = new JLabel("Username:");
        userLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        userLbl.setForeground(ThemeUI.TEXT_DARK);

        JLabel passLbl = new JLabel("Password:");
        passLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passLbl.setForeground(ThemeUI.TEXT_DARK);

        username.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        username.setPreferredSize(new Dimension(240, 36));
        password.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        password.setPreferredSize(new Dimension(240, 36));

        gbc.gridx = 0; gbc.gridy = 0;
        formCard.add(userLbl, gbc);
        gbc.gridx = 1;
        formCard.add(username, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formCard.add(passLbl, gbc);
        gbc.gridx = 1;
        formCard.add(password, gbc);

        JButton login = new JButton("Login to Portal");
        JButton register = new JButton("New Registration");
        ThemeUI.styleButton(login, ThemeUI.BTN_PRIMARY, Color.WHITE);
        ThemeUI.styleButton(register, ThemeUI.PASTEL_LAVENDER, ThemeUI.TEXT_DARK);
        getRootPane().setDefaultButton(login);

        login.addActionListener(e -> loginUser());
        password.addActionListener(e -> loginUser());
        register.addActionListener(e -> {
            new RegisterFrame(this).setVisible(true);
            setVisible(false);
        });

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setOpaque(false);
        btnPanel.add(login);
        btnPanel.add(register);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.insets = new Insets(18, 10, 0, 10);
        formCard.add(btnPanel, gbc);

        centerWrapper.add(formCard);
        add(centerWrapper, BorderLayout.CENTER);
    }

    private void loginUser() {
        String user = username.getText().trim();
        String pass = new String(password.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter username and password.");
            return;
        }

        String sql = "SELECT * FROM app_users WHERE username = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next() || !PasswordUtil.verify(pass, rs.getString("password_hash"))) {
                    JOptionPane.showMessageDialog(this, "Invalid username or password.");
                    return;
                }

                int userId = 1;
                try {
                    userId = rs.getInt("id");
                } catch (SQLException e) {
                    try {
                        userId = rs.getInt("user_id");
                    } catch (SQLException ignored) {}
                }

                String name = rs.getString("full_name");
                String role = rs.getString("role");

                dispose();

                if ("CANTEEN_STAFF".equalsIgnoreCase(role)) {
                    new CanteenStaffDashboard(userId, name).setVisible(true);
                } else {
                    new UserDashboard(userId, name).setVisible(true);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database connection failed:\n" + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error during login: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
