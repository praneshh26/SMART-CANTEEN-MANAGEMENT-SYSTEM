package canteen;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDashboard extends JFrame {
    private final int userId;
    private final String userName;

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(cardLayout);

    private final JLabel userInfoLabel = new JLabel();
    private final JLabel walletLabel = new JLabel();

    private final JButton viewCartBtn = new JButton("View Cart (0 items) - ₹0.00");

    private final DefaultTableModel menuModel = new DefaultTableModel(
            new String[]{"Item ID", "Item Name", "Category", "Price (₹)", "Stock Qty", "Status"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final DefaultTableModel orderModel = new DefaultTableModel(
            new String[]{"Order ID", "Token No", "Total (₹)", "Status", "Order Date"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable menuTable = new JTable(menuModel);
    private final JTable orderTable = new JTable(orderModel);

    private static class CartItem {
        int itemId;
        String itemName;
        double price;
        int quantity;

        CartItem(int itemId, String itemName, double price, int quantity) {
            this.itemId = itemId;
            this.itemName = itemName;
            this.price = price;
            this.quantity = quantity;
        }

        double getSubtotal() {
            return price * quantity;
        }
    }

    private final List<CartItem> cartList = new ArrayList<>();

    public UserDashboard() {
        this(1, "Customer");
    }

    public UserDashboard(int userId, String name) {
        this.userId = userId;
        this.userName = name;

        setTitle("Smart Canteen - Customer Portal");
        setSize(1100, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(ThemeUI.BG_CREAM);

        // ---------------- TOP HEADER BAR ----------------
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(ThemeUI.HEADER_SAGE);
        topBar.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        JPanel userInfoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        userInfoPanel.setOpaque(false);

        JLabel logoSmall = new JLabel(ThemeUI.createCanteenIcon("LOGO", 32));
        userInfoLabel.setText("ID: #" + userId + "  |  Name: " + userName);
        userInfoLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        userInfoLabel.setForeground(Color.WHITE);

        walletLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        walletLabel.setForeground(ThemeUI.PASTEL_MINT);

        userInfoPanel.add(logoSmall);
        userInfoPanel.add(userInfoLabel);
        userInfoPanel.add(walletLabel);

        JPanel topActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        topActions.setOpaque(false);

        JButton homeBtn = new JButton("Home");
        JButton refreshBtn = new JButton("Refresh");
        JButton logoutBtn = new JButton("Logout");
        ThemeUI.styleButton(homeBtn, ThemeUI.PASTEL_SKY, ThemeUI.TEXT_DARK);
        ThemeUI.styleButton(refreshBtn, ThemeUI.PASTEL_MINT, ThemeUI.TEXT_DARK);
        ThemeUI.styleButton(logoutBtn, ThemeUI.PASTEL_PEACH, ThemeUI.TEXT_DARK);

        homeBtn.addActionListener(e -> {
            loadAllData();
            cardLayout.show(contentPanel, "HOME");
        });
        refreshBtn.addActionListener(e -> loadAllData());
        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        topActions.add(homeBtn);
        topActions.add(refreshBtn);
        topActions.add(logoutBtn);

        topBar.add(userInfoPanel, BorderLayout.WEST);
        topBar.add(topActions, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // ---------------- CARD SCREENS ----------------
        contentPanel.setBackground(ThemeUI.BG_CREAM);
        contentPanel.add(createHomeSelectionPanel(), "HOME");
        contentPanel.add(createFullMenuOrderPanel(), "ORDER_MENU");
        contentPanel.add(createOrderHistoryPanel(), "ORDER_HISTORY");

        add(contentPanel, BorderLayout.CENTER);

        ThemeUI.styleTable(menuTable);
        ThemeUI.styleTable(orderTable);
        configureMenuTableRenderer();
        loadAllData();
        cardLayout.show(contentPanel, "HOME");
    }

    private JPanel createHomeSelectionPanel() {
        JPanel homePanel = new JPanel(new BorderLayout(20, 20));
        homePanel.setBackground(ThemeUI.BG_CREAM);
        homePanel.setBorder(BorderFactory.createEmptyBorder(45, 80, 60, 80));

        JLabel heading = new JLabel("Welcome, " + userName + "! What would you like to do today?", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 22));
        heading.setForeground(ThemeUI.HEADER_SAGE);
        homePanel.add(heading, BorderLayout.NORTH);

        JPanel cardsGrid = new JPanel(new GridLayout(1, 2, 35, 25));
        cardsGrid.setOpaque(false);
        cardsGrid.setBorder(BorderFactory.createEmptyBorder(25, 20, 30, 20));

        cardsGrid.add(createChoiceCard(
                "Place Order",
                "Browse the full canteen menu, check live item availability, add quantities to your cart, and generate a token.",
                "Browse Menu & Order",
                ThemeUI.createCanteenIcon("MENU", 54),
                ThemeUI.PASTEL_MINT,
                e -> {
                    loadAllData();
                    cardLayout.show(contentPanel, "ORDER_MENU");
                }
        ));

        cardsGrid.add(createChoiceCard(
                "Order History & Live Orders",
                "Track your active token statuses in real time, review past orders, or cancel pending orders for an instant wallet refund.",
                "View My Orders",
                ThemeUI.createCanteenIcon("HISTORY", 54),
                ThemeUI.PASTEL_SKY,
                e -> {
                    loadAllData();
                    cardLayout.show(contentPanel, "ORDER_HISTORY");
                }
        ));

        homePanel.add(cardsGrid, BorderLayout.CENTER);
        return homePanel;
    }

    private JPanel createChoiceCard(String title, String description, String buttonText, Icon icon, Color cardBg, java.awt.event.ActionListener action) {
        JPanel card = new JPanel(new BorderLayout(15, 15));
        card.setBackground(cardBg);
        card.setBorder(ThemeUI.roundedCardBorder(ThemeUI.BORDER_SOFT, 30, 28));

        JPanel topHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        topHeader.setOpaque(false);
        JLabel iconLbl = new JLabel(icon);
        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(ThemeUI.TEXT_DARK);
        topHeader.add(iconLbl);
        topHeader.add(titleLbl);

        JTextArea descArea = new JTextArea(description);
        descArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        descArea.setForeground(ThemeUI.TEXT_DARK);
        descArea.setWrapStyleWord(true);
        descArea.setLineWrap(true);
        descArea.setEditable(false);
        descArea.setOpaque(false);
        descArea.setFocusable(false);

        JButton btn = new JButton(buttonText);
        ThemeUI.styleButton(btn, ThemeUI.HEADER_SAGE, Color.WHITE);
        btn.setPreferredSize(new Dimension(210, 44));
        btn.addActionListener(action);

        card.add(topHeader, BorderLayout.NORTH);
        card.add(descArea, BorderLayout.CENTER);
        card.add(btn, BorderLayout.SOUTH);
        return card;
    }

    private JPanel createFullMenuOrderPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(ThemeUI.BG_CREAM);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JPanel topNav = new JPanel(new BorderLayout());
        topNav.setOpaque(false);

        JPanel leftNav = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        leftNav.setOpaque(false);
        JButton backBtn = new JButton("← Back");
        ThemeUI.styleButton(backBtn, ThemeUI.PASTEL_LAVENDER, ThemeUI.TEXT_DARK);
        backBtn.addActionListener(e -> cardLayout.show(contentPanel, "HOME"));

        JLabel title = new JLabel("  Full Canteen Menu", ThemeUI.createCanteenIcon("MENU", 28), JLabel.LEFT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 17));
        title.setForeground(ThemeUI.HEADER_SAGE);
        leftNav.add(backBtn);
        leftNav.add(title);

        JLabel legendLbl = new JLabel("Items in RED are Not Available  ");
        legendLbl.setForeground(Color.RED);
        legendLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));

        topNav.add(leftNav, BorderLayout.WEST);
        topNav.add(legendLbl, BorderLayout.EAST);

        panel.add(topNav, BorderLayout.NORTH);
        panel.add(new JScrollPane(menuTable), BorderLayout.CENTER);

        JPanel bottomBar = new JPanel(new BorderLayout(15, 10));
        bottomBar.setOpaque(false);
        bottomBar.setBorder(BorderFactory.createEmptyBorder(8, 0, 5, 0));

        JButton addToCartBtn = new JButton("+ Add Selected Item to Cart");
        ThemeUI.styleButton(addToCartBtn, ThemeUI.BTN_PRIMARY, Color.WHITE);
        addToCartBtn.setPreferredSize(new Dimension(240, 42));
        addToCartBtn.addActionListener(e -> addItemToCart());

        ThemeUI.styleButton(viewCartBtn, ThemeUI.PASTEL_PEACH, ThemeUI.TEXT_DARK);
        viewCartBtn.setPreferredSize(new Dimension(280, 42));
        viewCartBtn.addActionListener(e -> openViewCartDialog());

        bottomBar.add(addToCartBtn, BorderLayout.WEST);
        bottomBar.add(viewCartBtn, BorderLayout.EAST);

        panel.add(bottomBar, BorderLayout.SOUTH);
        return panel;
    }

    private void configureMenuTableRenderer() {
        DefaultTableCellRenderer statusRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                int modelRow = table.convertRowIndexToModel(row);
                String status = String.valueOf(menuModel.getValueAt(modelRow, 5));
                boolean isUnavailable = "NOT AVAILABLE".equalsIgnoreCase(status);

                if (isUnavailable) {
                    c.setForeground(Color.RED);
                    c.setFont(c.getFont().deriveFont(Font.BOLD));
                    if (!isSelected) c.setBackground(new Color(255, 242, 242));
                } else {
                    if (!isSelected) c.setBackground(Color.WHITE);
                    c.setForeground(column == 5 ? new Color(0, 128, 0) : ThemeUI.TEXT_DARK);
                }
                return c;
            }
        };

        for (int i = 0; i < menuTable.getColumnCount(); i++) {
            menuTable.getColumnModel().getColumn(i).setCellRenderer(statusRenderer);
        }
    }

    private void addItemToCart() {
        int row = menuTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a food item from the menu first.");
            return;
        }

        int modelRow = menuTable.convertRowIndexToModel(row);
        int itemId = (Integer) menuModel.getValueAt(modelRow, 0);
        String itemName = (String) menuModel.getValueAt(modelRow, 1);
        double price = (Double) menuModel.getValueAt(modelRow, 3);
        int availableStock = (Integer) menuModel.getValueAt(modelRow, 4);
        String status = (String) menuModel.getValueAt(modelRow, 5);

        if ("NOT AVAILABLE".equalsIgnoreCase(status) || availableStock <= 0) {
            JOptionPane.showMessageDialog(this, "'" + itemName + "' is currently NOT AVAILABLE.", "Unavailable Item", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String qtyStr = JOptionPane.showInputDialog(this, "Enter quantity for " + itemName + " (Available: " + availableStock + "):", "1");
        if (qtyStr == null || qtyStr.trim().isEmpty()) {
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyStr.trim());
            if (qty <= 0) {
                JOptionPane.showMessageDialog(this, "Quantity must be greater than zero.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid quantity entered.");
            return;
        }

        int currentCartQty = 0;
        CartItem existing = null;
        for (CartItem ci : cartList) {
            if (ci.itemId == itemId) {
                currentCartQty = ci.quantity;
                existing = ci;
                break;
            }
        }

        if (currentCartQty + qty > availableStock) {
            JOptionPane.showMessageDialog(this, "Cannot exceed available stock (" + availableStock + "). Already in cart: " + currentCartQty);
            return;
        }

        if (existing != null) {
            existing.quantity += qty;
        } else {
            cartList.add(new CartItem(itemId, itemName, price, qty));
        }

        updateViewCartButton();
        JOptionPane.showMessageDialog(this, "Added " + qty + " x " + itemName + " to cart.");
    }

    private void updateViewCartButton() {
        int totalQty = 0;
        double totalAmt = 0.0;
        for (CartItem ci : cartList) {
            totalQty += ci.quantity;
            totalAmt += ci.getSubtotal();
        }
        viewCartBtn.setText("View Cart (" + totalQty + " items) - ₹" + String.format("%.2f", totalAmt));
    }

    private void openViewCartDialog() {
        if (cartList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your cart is currently empty. Select items from the menu first.");
            return;
        }

        JDialog cartDialog = new JDialog(this, "My Cart & Order Summary", true);
        cartDialog.setSize(680, 460);
        cartDialog.setLocationRelativeTo(this);
        cartDialog.setLayout(new BorderLayout(10, 10));
        cartDialog.getContentPane().setBackground(ThemeUI.BG_CREAM);

        DefaultTableModel popupCartModel = new DefaultTableModel(
                new String[]{"Item ID", "Item Name", "Unit Price (₹)", "Quantity", "Subtotal (₹)"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        JTable popupCartTable = new JTable(popupCartModel);
        ThemeUI.styleTable(popupCartTable);

        JLabel grandTotalLbl = new JLabel();
        grandTotalLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        grandTotalLbl.setForeground(ThemeUI.HEADER_SAGE);

        Runnable refreshDialogData = () -> {
            popupCartModel.setRowCount(0);
            double total = 0.0;
            for (CartItem ci : cartList) {
                double sub = ci.getSubtotal();
                total += sub;
                popupCartModel.addRow(new Object[]{
                        ci.itemId,
                        ci.itemName,
                        String.format("%.2f", ci.price),
                        ci.quantity,
                        String.format("%.2f", sub)
                });
            }
            grandTotalLbl.setText("Grand Total: ₹" + String.format("%.2f", total));
            updateViewCartButton();
        };

        refreshDialogData.run();

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        topPanel.setBackground(ThemeUI.PASTEL_MINT);
        JLabel header = new JLabel("Review Your Cart Items Before Placing Order");
        header.setFont(new Font("Segoe UI", Font.BOLD, 15));
        topPanel.add(header);
        cartDialog.add(topPanel, BorderLayout.NORTH);

        cartDialog.add(new JScrollPane(popupCartTable), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBackground(ThemeUI.BG_CREAM);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 15));

        JButton removeBtn = new JButton("Remove Selected Item");
        ThemeUI.styleButton(removeBtn, ThemeUI.PASTEL_PEACH, ThemeUI.TEXT_DARK);
        removeBtn.addActionListener(e -> {
            int selRow = popupCartTable.getSelectedRow();
            if (selRow < 0) {
                JOptionPane.showMessageDialog(cartDialog, "Select an item to remove.");
                return;
            }
            cartList.remove(selRow);
            refreshDialogData.run();
            if (cartList.isEmpty()) {
                cartDialog.dispose();
            }
        });

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        rightActions.setOpaque(false);
        JButton placeOrderBtn = new JButton("Place Order");
        ThemeUI.styleButton(placeOrderBtn, ThemeUI.BTN_PRIMARY, Color.WHITE);
        placeOrderBtn.setPreferredSize(new Dimension(150, 38));

        placeOrderBtn.addActionListener(e -> {
            boolean success = executeCheckoutTransaction(cartDialog);
            if (success) {
                cartDialog.dispose();
                cardLayout.show(contentPanel, "ORDER_HISTORY");
            }
        });

        rightActions.add(grandTotalLbl);
        rightActions.add(placeOrderBtn);

        bottomPanel.add(removeBtn, BorderLayout.WEST);
        bottomPanel.add(rightActions, BorderLayout.EAST);

        cartDialog.add(bottomPanel, BorderLayout.SOUTH);
        cartDialog.setVisible(true);
    }

    private boolean executeCheckoutTransaction(Component parentComponent) {
        if (cartList.isEmpty()) return false;

        double grandTotal = 0.0;
        int totalItemsCount = 0;
        for (CartItem ci : cartList) {
            grandTotal += ci.getSubtotal();
            totalItemsCount += ci.quantity;
        }

        int confirm = JOptionPane.showConfirmDialog(
                parentComponent,
                "Confirm order of " + totalItemsCount + " item(s) for ₹" + String.format("%.2f", grandTotal) + "?",
                "Confirm Order",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return false;

        Connection con = null;
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            double currentBalance = 0.0;
            String checkWalletSql = "SELECT balance FROM user_wallets WHERE user_id = ? FOR UPDATE";
            try (PreparedStatement ps = con.prepareStatement(checkWalletSql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        currentBalance = rs.getDouble("balance");
                    } else {
                        con.rollback();
                        JOptionPane.showMessageDialog(parentComponent, "Wallet account not found. Please recharge at the canteen counter.");
                        return false;
                    }
                }
            }

            if (currentBalance < grandTotal) {
                con.rollback();
                JOptionPane.showMessageDialog(parentComponent, "Insufficient balance!\nRequired: ₹" + String.format("%.2f", grandTotal)
                        + "\nAvailable: ₹" + String.format("%.2f", currentBalance));
                return false;
            }

            String checkStockSql = "SELECT stock_quantity FROM menu_items WHERE item_id = ? AND UPPER(available) = 'Y' FOR UPDATE";
            for (CartItem ci : cartList) {
                try (PreparedStatement ps = con.prepareStatement(checkStockSql)) {
                    ps.setInt(1, ci.itemId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next() || rs.getInt("stock_quantity") < ci.quantity) {
                            con.rollback();
                            JOptionPane.showMessageDialog(parentComponent, "Item '" + ci.itemName + "' is out of stock or has insufficient quantity.");
                            loadAllData();
                            return false;
                        }
                    }
                }
            }

            int tokenNo = (int) ((System.currentTimeMillis() / 1000) % 900) + 100;

            String deductWalletSql = "UPDATE user_wallets SET balance = balance - ? WHERE user_id = ?";
            try (PreparedStatement ps = con.prepareStatement(deductWalletSql)) {
                ps.setDouble(1, grandTotal);
                ps.setInt(2, userId);
                ps.executeUpdate();
            }

            String recordTxnSql = "INSERT INTO wallet_transactions (user_id, type, amount) VALUES (?, 'PURCHASE', ?)";
            try (PreparedStatement ps = con.prepareStatement(recordTxnSql)) {
                ps.setInt(1, userId);
                ps.setDouble(2, grandTotal);
                ps.executeUpdate();
            }

            String deductStockSql = "UPDATE menu_items SET stock_quantity = stock_quantity - ?, "
                    + "available = IF(stock_quantity - ? > 0, 'Y', 'N') WHERE item_id = ?";
            try (PreparedStatement ps = con.prepareStatement(deductStockSql)) {
                for (CartItem ci : cartList) {
                    ps.setInt(1, ci.quantity);
                    ps.setInt(2, ci.quantity);
                    ps.setInt(3, ci.itemId);
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            String insertOrderSql = "INSERT INTO orders (user_id, total_amount, token_no, status, order_date) "
                    + "VALUES (?, ?, ?, 'PENDING', CURRENT_TIMESTAMP)";
            try (PreparedStatement ps = con.prepareStatement(insertOrderSql)) {
                ps.setInt(1, userId);
                ps.setDouble(2, grandTotal);
                ps.setInt(3, tokenNo);
                ps.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(parentComponent,
                    "Order Placed Successfully!\n\n"
                            + "Token No: #" + tokenNo + "\n"
                            + "Total Paid: ₹" + String.format("%.2f", grandTotal) + "\n\n"
                            + "Show Token #" + tokenNo + " at the canteen counter.",
                    "Order Confirmed",
                    JOptionPane.INFORMATION_MESSAGE
            );

            cartList.clear();
            updateViewCartButton();
            loadAllData();
            return true;

        } catch (SQLException ex) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ignored) {}
            }
            showError(ex);
            return false;
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ignored) {}
            }
        }
    }

    private JPanel createOrderHistoryPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(ThemeUI.BG_CREAM);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JPanel topNav = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        topNav.setOpaque(false);
        JButton backBtn = new JButton("← Back");
        ThemeUI.styleButton(backBtn, ThemeUI.PASTEL_LAVENDER, ThemeUI.TEXT_DARK);
        backBtn.addActionListener(e -> cardLayout.show(contentPanel, "HOME"));

        JLabel title = new JLabel("  My Order History & Live Orders", ThemeUI.createCanteenIcon("HISTORY", 28), JLabel.LEFT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 17));
        title.setForeground(ThemeUI.HEADER_SAGE);
        topNav.add(backBtn);
        topNav.add(title);

        panel.add(topNav, BorderLayout.NORTH);
        panel.add(new JScrollPane(orderTable), BorderLayout.CENTER);

        JPanel bottomBar = new JPanel(new BorderLayout());
        bottomBar.setOpaque(false);
        bottomBar.setBorder(BorderFactory.createEmptyBorder(8, 0, 5, 0));

        JLabel infoLbl = new JLabel("Select a live order (PENDING / PREPARING) to cancel and refund to wallet.");
        infoLbl.setForeground(ThemeUI.TEXT_DARK);

        JButton cancelOrderBtn = new JButton("Cancel Selected Live Order");
        ThemeUI.styleButton(cancelOrderBtn, ThemeUI.BTN_DANGER, Color.WHITE);
        cancelOrderBtn.setPreferredSize(new Dimension(230, 38));
        cancelOrderBtn.setEnabled(false);

        orderTable.getSelectionModel().addListSelectionListener(e -> {
            int row = orderTable.getSelectedRow();
            if (row >= 0) {
                int modelRow = orderTable.convertRowIndexToModel(row);
                String status = String.valueOf(orderModel.getValueAt(modelRow, 3));
                boolean isLiveCancellable = "PENDING".equalsIgnoreCase(status) || "PREPARING".equalsIgnoreCase(status);
                cancelOrderBtn.setEnabled(isLiveCancellable);
            } else {
                cancelOrderBtn.setEnabled(false);
            }
        });

        cancelOrderBtn.addActionListener(e -> cancelSelectedOrder());

        bottomBar.add(infoLbl, BorderLayout.WEST);
        bottomBar.add(cancelOrderBtn, BorderLayout.EAST);

        panel.add(bottomBar, BorderLayout.SOUTH);
        return panel;
    }

    private void cancelSelectedOrder() {
        int row = orderTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an order to cancel.");
            return;
        }

        int modelRow = orderTable.convertRowIndexToModel(row);
        int orderId = (Integer) orderModel.getValueAt(modelRow, 0);
        int tokenNo = (Integer) orderModel.getValueAt(modelRow, 1);
        double totalAmount = (Double) orderModel.getValueAt(modelRow, 2);
        String status = String.valueOf(orderModel.getValueAt(modelRow, 3));

        if (!"PENDING".equalsIgnoreCase(status) && !"PREPARING".equalsIgnoreCase(status)) {
            JOptionPane.showMessageDialog(this, "Only live orders (PENDING or PREPARING) can be cancelled.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to cancel Token #" + tokenNo + "?\n"
                        + "₹" + String.format("%.2f", totalAmount) + " will be refunded to your wallet.",
                "Confirm Order Cancellation",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        Connection con = null;
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            String checkStatusSql = "SELECT status, total_amount FROM orders WHERE order_id = ? AND user_id = ? FOR UPDATE";
            double refundAmount;
            try (PreparedStatement ps = con.prepareStatement(checkStatusSql)) {
                ps.setInt(1, orderId);
                ps.setInt(2, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        con.rollback();
                        JOptionPane.showMessageDialog(this, "Order not found.");
                        return;
                    }
                    String dbStatus = rs.getString("status");
                    refundAmount = rs.getDouble("total_amount");
                    if (!"PENDING".equalsIgnoreCase(dbStatus) && !"PREPARING".equalsIgnoreCase(dbStatus)) {
                        con.rollback();
                        JOptionPane.showMessageDialog(this, "Cannot cancel: Order status is already " + dbStatus + ".");
                        loadAllData();
                        return;
                    }
                }
            }

            String cancelSql = "UPDATE orders SET status = 'CANCELLED' WHERE order_id = ?";
            try (PreparedStatement ps = con.prepareStatement(cancelSql)) {
                ps.setInt(1, orderId);
                ps.executeUpdate();
            }

            String refundWalletSql = "UPDATE user_wallets SET balance = balance + ? WHERE user_id = ?";
            try (PreparedStatement ps = con.prepareStatement(refundWalletSql)) {
                ps.setDouble(1, refundAmount);
                ps.setInt(2, userId);
                ps.executeUpdate();
            }

            String txnSql = "INSERT INTO wallet_transactions (user_id, type, amount) VALUES (?, 'REFUND', ?)";
            try (PreparedStatement ps = con.prepareStatement(txnSql)) {
                ps.setInt(1, userId);
                ps.setDouble(2, refundAmount);
                ps.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(this,
                    "Order Token #" + tokenNo + " has been cancelled.\n"
                            + "₹" + String.format("%.2f", refundAmount) + " has been refunded to your wallet.",
                    "Order Cancelled",
                    JOptionPane.INFORMATION_MESSAGE
            );

            loadAllData();

        } catch (SQLException ex) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ignored) {}
            }
            showError(ex);
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ignored) {}
            }
        }
    }

    private void loadAllData() {
        menuModel.setRowCount(0);
        orderModel.setRowCount(0);

        String walletSql = "SELECT balance FROM user_wallets WHERE user_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(walletSql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double balance = rs.getDouble("balance");
                    walletLabel.setText("  |  Wallet: ₹" + String.format("%.2f", balance));
                } else {
                    walletLabel.setText("  |  Wallet: ₹0.00");
                }
            }
        } catch (SQLException ex) {
            showError(ex);
        }

        String menuSql = "SELECT item_id, item_name, category, price, stock_quantity, available "
                + "FROM menu_items ORDER BY category, item_name";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(menuSql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int stock = rs.getInt("stock_quantity");
                String availFlag = rs.getString("available");
                boolean isAvailable = "Y".equalsIgnoreCase(availFlag) && stock > 0;

                menuModel.addRow(new Object[]{
                        rs.getInt("item_id"),
                        rs.getString("item_name"),
                        rs.getString("category"),
                        rs.getDouble("price"),
                        stock,
                        isAvailable ? "AVAILABLE" : "NOT AVAILABLE"
                });
            }
        } catch (SQLException ex) {
            showError(ex);
        }

        String ordersSql = "SELECT order_id, token_no, total_amount, status, order_date "
                + "FROM orders WHERE user_id = ? ORDER BY order_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(ordersSql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    orderModel.addRow(new Object[]{
                            rs.getInt("order_id"),
                            rs.getInt("token_no"),
                            rs.getDouble("total_amount"),
                            rs.getString("status"),
                            rs.getString("order_date")
                    });
                }
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void showError(SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
