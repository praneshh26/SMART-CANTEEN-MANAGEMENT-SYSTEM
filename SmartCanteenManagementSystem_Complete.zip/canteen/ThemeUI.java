package canteen;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;

public class ThemeUI {
    // Pastel Color Palette (for backgrounds, banners, and cards)
    public static final Color BG_CREAM = new Color(252, 249, 244);        // Warm pastel cream background
    public static final Color HEADER_SAGE = new Color(74, 108, 111);      // Deep muted sage-slate header
    public static final Color PASTEL_MINT = new Color(216, 243, 220);     // Soft mint card / accent
    public static final Color PASTEL_PEACH = new Color(255, 229, 217);    // Soft peach card / accent
    public static final Color PASTEL_LAVENDER = new Color(234, 228, 242); // Soft lavender accent
    public static final Color PASTEL_SKY = new Color(217, 237, 247);      // Soft sky blue accent
    public static final Color CARD_WHITE = new Color(255, 255, 255);      // Clean white card surface
    public static final Color BORDER_SOFT = new Color(215, 220, 225);     // Gentle border line

    public static final Color BTN_PRIMARY = new Color(106, 158, 136);
    public static final Color BTN_DANGER = new Color(224, 108, 108);
    public static final Color TEXT_DARK = new Color(45, 52, 54);          // Charcoal text

    public static Border roundedCardBorder(Color lineColor, int padV, int padH) {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(lineColor, 1, true),
                BorderFactory.createEmptyBorder(padV, padH, padV, padH)
        );
    }

    // Keeps the clean default Swing/System button appearance with neat font & hand cursor
    public static void styleButton(JButton btn, Color bg, Color fg) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setGridColor(new Color(235, 238, 240));
        table.setSelectionBackground(PASTEL_SKY);
        table.setSelectionForeground(TEXT_DARK);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(PASTEL_LAVENDER);
        table.getTableHeader().setForeground(TEXT_DARK);
    }

    // Built-in Vector Icon Generator (No external image files required)
    public static Icon createCanteenIcon(String type, int size) {
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.translate(x, y);

                switch (type) {
                    case "LOGO": // Canteen Cloche / Food Dome
                        g2.setColor(PASTEL_PEACH);
                        g2.fill(new Ellipse2D.Double(2, 2, size - 4, size - 4));
                        g2.setColor(HEADER_SAGE);
                        g2.fill(new Arc2D.Double(size * 0.2, size * 0.28, size * 0.6, size * 0.52, 0, 180, Arc2D.PIE));
                        g2.fillRoundRect((int)(size * 0.15), (int)(size * 0.56), (int)(size * 0.7), (int)(size * 0.1), 6, 6);
                        g2.fillOval((int)(size * 0.45), (int)(size * 0.18), (int)(size * 0.1), (int)(size * 0.1));
                        break;

                    case "MENU": // Plate Graphic
                        g2.setColor(PASTEL_MINT);
                        g2.fillRoundRect(2, 2, size - 4, size - 4, 14, 14);
                        g2.setColor(new Color(46, 125, 50));
                        g2.setStroke(new BasicStroke(2.2f));
                        g2.drawOval((int)(size * 0.25), (int)(size * 0.25), (int)(size * 0.5), (int)(size * 0.5));
                        g2.drawOval((int)(size * 0.34), (int)(size * 0.34), (int)(size * 0.32), (int)(size * 0.32));
                        break;

                    case "HISTORY": // Order Receipt / Token Graphic
                        g2.setColor(PASTEL_SKY);
                        g2.fillRoundRect(2, 2, size - 4, size - 4, 14, 14);
                        g2.setColor(new Color(21, 101, 192));
                        g2.setStroke(new BasicStroke(2.2f));
                        g2.drawRoundRect((int)(size * 0.26), (int)(size * 0.2), (int)(size * 0.48), (int)(size * 0.6), 6, 6);
                        g2.drawLine((int)(size * 0.36), (int)(size * 0.38), (int)(size * 0.64), (int)(size * 0.38));
                        g2.drawLine((int)(size * 0.36), (int)(size * 0.52), (int)(size * 0.64), (int)(size * 0.52));
                        g2.drawLine((int)(size * 0.36), (int)(size * 0.66), (int)(size * 0.54), (int)(size * 0.66));
                        break;

                    case "WALLET": // Wallet Graphic
                        g2.setColor(PASTEL_PEACH);
                        g2.fillRoundRect(2, 2, size - 4, size - 4, 14, 14);
                        g2.setColor(new Color(230, 81, 0));
                        g2.setStroke(new BasicStroke(2.2f));
                        g2.drawRoundRect((int)(size * 0.2), (int)(size * 0.3), (int)(size * 0.6), (int)(size * 0.42), 8, 8);
                        g2.fillOval((int)(size * 0.62), (int)(size * 0.46), (int)(size * 0.1), (int)(size * 0.1));
                        break;
                }
                g2.dispose();
            }

            @Override
            public int getIconWidth() { return size; }

            @Override
            public int getIconHeight() { return size; }
        };
    }
}
